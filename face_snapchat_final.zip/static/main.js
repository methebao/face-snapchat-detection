(function($) {
  function addEndpoint(isChecked) {
    if (isChecked) {
      $(".draw-links").each(function() {
        $(this).attr("href", $(this).attr("href") + "/1");
      });
    } else {
      $(".draw-links").each(function() {
        $(this).attr(
          "href",
          $(this)
            .attr("href")
            .replace("/1", "")
        );
      });
    }
  }
  if ($("#isRecording").is(":checked")) {
    addEndpoint(this.checked);
  }
  $("#isRecording").change(function() {
    addEndpoint(this.checked);
  });
  // debugger;
  // $("#drawButtons a").each(function() {
  //   debugger;
  //   $(this).click(function() {
  //     debugger;
  //     if ($("#isRecording").is(":checked")) {
  //       $(".draw-links").each(function() {
  //         $(this).attr("href", $(this).attr("href") + "/1");
  //       });
  //     }
  //   });
  // });
  $(document).ready(function() {
    $("input:checkbox").prop("checked", false);
  });
})(jQuery);
